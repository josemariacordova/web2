"use client"

import Image from "next/image"
import { useState } from "react"

export default function ComingSoon() {
  const [copied, setCopied] = useState(false)

  const handleContact = () => {
    // Check if mobile
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent)

    if (isMobile) {
      window.location.href = "mailto:robdaniels.design@gmail.com"
    } else {
      navigator.clipboard.writeText("robdaniels.design@gmail.com")
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <>
      <div className="relative min-h-screen w-full overflow-hidden bg-white">
        <div className="absolute inset-0 w-full h-full opacity-50">
          <video
            className="absolute inset-0 w-full h-full object-cover"
            style={{ objectPosition: "center 30%" }}
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            controls={false}
          >
            <source src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/dragonfly_1-AArbVslKJaSOISmjzaZq8AMubYXZLL.mp4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>

        <header className="relative z-10 px-6 py-5">
          <div className="flex items-center justify-between">
            <button className="logo-hover transition-all">
              <Image src="/images/rob-mark.svg" alt="Rob Mark" width={38} height={38} className="w-10 h-10" />
            </button>

            <button
              onClick={handleContact}
              className="font-alfabet font-light text-black text-[10px] md:text-xs border border-black px-5 py-1.5 hover:bg-[#FF003C] hover:border-[#FF003C] hover:text-white transition-colors"
              style={{ borderRadius: "4px" }}
            >
              {copied ? "COPIED!" : "CONTACT"}
            </button>
          </div>

          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
            <h2 className="hidden md:block font-ivyjournal font-normal text-black text-xs md:text-sm whitespace-nowrap">
              ( ROB FIGUEREDO )
            </h2>
          </div>
        </header>

        <div className="relative z-10 flex min-h-[calc(100vh-88px)] items-center justify-center px-6">
          <div className="text-center flex flex-col items-center">
            <div className="text-black text-base font-light mb-3">+</div>

            <div className="w-px h-20 bg-black/30 mb-6" />

            <div className="text-black text-base font-light mb-6">+</div>

            <h1 className="font-ivyjournal font-thin text-black text-3xl md:text-4xl lg:text-5xl max-w-[740px] leading-tight mb-10">
              World-class visual designer
              <br />
              with a keen attention to detail.
            </h1>

            <div className="text-black text-base font-light mb-3">+</div>

            <div className="w-px h-20 bg-black/30" />

            <div className="text-black text-base font-light mt-3">+</div>
          </div>
        </div>
      </div>

      {/* LIFE OF MANSOOR PROJECT */}
      <section className="bg-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 mb-16">
            <div>
              <h3 className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-2">LIFE OF MANSOOR</h3>
              <p className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-6">
                MADE YOU LOOK - POSTER SERIES WEBSITE
              </p>

              <div className="flex flex-wrap gap-2">
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  ART DIRECTION
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  WEB DESIGN
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  WEB DEV
                </span>
              </div>
            </div>

            <div>
              <h4 className="font-ivyjournal italic font-normal text-black text-2xl md:text-3xl mb-4">
                Discovering 3D on the web through the power of AI tools.
              </h4>
              <p className="font-alfabet font-light text-black text-sm md:text-base leading-relaxed">
                Graphic Designer and friend, Mansoor, was looking for help to build a home for his daily poster series.
                He drops a new poster every day on social media, but these have yet to all be collected in one spot. He
                had a concept in his head of a globe with the posters mapped out to spin through. I brought this idea to
                life using vibe coding tools, and explored additional pages to add to the world building.
              </p>
            </div>
          </div>

          <div className="space-y-8">
            <video className="w-full h-auto border-[0.5px] border-black" autoPlay muted loop playsInline preload="auto">
              <source src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mansoor%201-4KOVuFGj9tZSIYqVlN06KzZbXlN0vu.mp4" type="video/mp4" />
            </video>

            <video className="w-full h-auto border-[0.5px] border-black" autoPlay muted loop playsInline preload="auto">
              <source src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mansoor%202-FBIWnI3o1BGoFKNA3DmRlnBs54TeIe.mp4" type="video/mp4" />
            </video>

            <Image
              src="/images/mansoor-3.jpg"
              alt="Mansoor project screenshots"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <video className="w-full h-auto" autoPlay muted loop playsInline preload="auto">
              <source src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Mansoor%204-OmiBIkwu5GNwAvLxaOQi811GgIzQQu.mp4" type="video/mp4" />
            </video>
          </div>
        </div>
      </section>

      {/* SUPERPOWER PROJECT */}
      <section className="bg-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 mb-16">
            <div>
              <h3 className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-2">SUPERPOWER</h3>
              <p className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-6">
                MARKETING DESIGN - FREELANCE
              </p>

              <div className="flex flex-wrap gap-2">
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  MARKETING DESIGN
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  GRAPHIC DESIGN
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  WEB DESIGN
                </span>
              </div>
            </div>

            <div>
              <h4 className="font-ivyjournal italic font-normal text-black text-2xl md:text-3xl mb-4">
                Helping out the marketing team of a startup in the health tech space (Series A $30M)
              </h4>
              <p className="font-alfabet font-light text-black text-sm md:text-base leading-relaxed">
                Superpower's founding designer Hannah Ahn tweeted that they were looking for some help to design
                marketing materials to wrap up the year. So I reached out to see if there might be a fit. We worked
                together on various marketing projects like landing pages, email campaigns and social media content.
              </p>
            </div>
          </div>

          <div className="space-y-8">
            <Image
              src="/images/sp-1.png"
              alt="Superpower Vitamin D infographic"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/sp-2.png"
              alt="Superpower landing page design"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/sp-3.png"
              alt="Superpower and Breathwrk collaboration"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/sp-4.png"
              alt="Superpower marketing materials"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/sp-5.png"
              alt="Superpower supplement stacks"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />
          </div>
        </div>
      </section>

      {/* METAGAME PROJECT */}
      <section className="bg-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 mb-16">
            <div>
              <h3 className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-2">METAGAME</h3>
              <p className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-6">
                BRANDING DIRECTION FEAT. PXL LABS
              </p>

              <div className="flex flex-wrap gap-2">
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  ART DIRECTION
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  BRAND IDENTITY
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  WEB DESIGN
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  SOCIAL MEDIA TEMPLATE
                </span>
              </div>
            </div>

            <div>
              <h4 className="font-ivyjournal italic font-normal text-black text-2xl md:text-3xl mb-4">
                A Gamified Web3 Experience with a dark twist
              </h4>
              <p className="font-alfabet font-light text-black text-sm md:text-base leading-relaxed">
                This was a collaboration with the team at PXL Labs, a web3 focused agency. The client came in with a
                clear vision of neon y2k and 3d chrome. I used a brutalist design style with a retro sci-fi/cyberpunk
                twist, acid graphics, and aspects of Y2K futurism. While we internally felt this direction nailed the
                client's brief, we ended up going a different direction in the final project.
              </p>
            </div>
          </div>

          <div className="space-y-8">
            <Image
              src="/images/design-mode/MG%20-%201.jpg"
              alt="Metagame landing page design"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/MG%20-%202.jpg"
              alt="Metagame logo variations"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/MG%20-%203.png"
              alt="Metagame brand guidelines"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/MG%20-%204.jpg"
              alt="Metagame partnership announcement"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/MG%20-%205.jpg"
              alt="Metagame traders become legends"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />
          </div>
        </div>
      </section>

      {/* JANNA LONG REAL ESTATE PROJECT */}
      <section className="bg-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 mb-16">
            <div>
              <h3 className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-2">
                JANNA LONG REAL ESTATE
              </h3>
              <p className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-6">
                BRANDING DIRECTION FEAT. SANDPAPER STUDIO
              </p>

              <div className="flex flex-wrap gap-2">
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  ART DIRECTION
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  BRAND IDENTITY
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  WEB DESIGN
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  SOCIAL MEDIA TEMPLATE
                </span>
              </div>
            </div>

            <div>
              <h4 className="font-ivyjournal italic font-normal text-black text-2xl md:text-3xl mb-4">
                A Brand Packing a Luxury Real Estate Aesthetic
              </h4>
              <p className="font-alfabet font-light text-black text-sm md:text-base leading-relaxed">
                Torrey Dawley has been posting inspiring content on Twitter for a while, we ended up connecting when he
                happened upon some of my work I've posted. After keeping in touch for a little while he found a project
                he felt would be perfect for my design sensibilities. I have a knack for making work that feels high end
                and restrained, which was a great fit here.
              </p>
            </div>
          </div>

          <div className="space-y-8">
            <Image
              src="/images/design-mode/JL-1.jpg"
              alt="Janna Long Real Estate logo on interior scene"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/JL-2.jpg"
              alt="Janna Long Real Estate website homepage"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/JL-3.jpg"
              alt="Janna Long Real Estate logo variations"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/JL-4.jpg"
              alt="Janna Long Real Estate stationery and brand collateral"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/JL-5.jpg"
              alt="Janna Long Real Estate mobile responsive design"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />
          </div>
        </div>
      </section>

      {/* HARVEST THEORY INC. PROJECT */}
      <section className="bg-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 mb-16">
            <div>
              <h3 className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-2">HARVEST</h3>
              <p className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-6">
                BRANDING DIRECTION - SIDE PROJECT
              </p>

              <div className="flex flex-wrap gap-2">
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  ART DIRECTION
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  BRAND IDENTITY
                </span>
                <span className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-4 py-1.5 rounded-full uppercase">
                  WEB DESIGN
                </span>
              </div>
            </div>

            <div>
              <h4 className="font-ivyjournal italic font-normal text-black text-2xl md:text-3xl mb-4">
                My favourite side project
              </h4>
              <p className="font-alfabet font-light text-black text-sm md:text-base leading-relaxed">
                This is a project I've been working on and off for a few years now, the mission has always been the
                same: to remind humans to stay human, to be creative and to be close to nature. I believe these idea's
                are fundamental to maintain our humanity and the more tech progresses, the more we get pushed away from
                it. So originally this was going to be my studio to serve clients close to nature, but I plan to pivot
                to media and content highlighting the wonders of nature.
              </p>
            </div>
          </div>

          <div className="space-y-8">
            <Image
              src="/images/design-mode/HT%20-%201.jpg"
              alt="Harvest Theory Inc. brand statement on red background"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/HT%20-%202.jpg"
              alt="Harvest Theory Inc. homepage hero with forest background"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/HT%20-%203.jpg"
              alt="Harvest Theory Inc. homepage with nature photography"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/HT%20-%204.jpg"
              alt="Harvest Theory Inc. video reel interface"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/HT%20-%205.jpg"
              alt="Harvest Theory Inc. manifesto page"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />

            <Image
              src="/images/design-mode/HT%20-%206.jpg"
              alt="Harvest Theory Inc. services page"
              width={1920}
              height={1080}
              className="w-full h-auto"
            />
          </div>
        </div>
      </section>

      {/* RESUME SECTION */}
      <section className="bg-[#f8f8f8] py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-center mb-16">
            <div className="font-alfabet font-normal text-black text-[10px] md:text-xs border border-black px-5 py-1.5 rounded-full uppercase">
              RESUME
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-16">
            {/* Education Column */}
            <div>
              <h3 className="font-ivyjournal italic font-normal text-black text-3xl md:text-4xl mb-12">Education</h3>

              <div className="space-y-10">
                <div>
                  <h4 className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-1">
                    GEORGIAN COLLEGE
                  </h4>
                  <p className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-1">
                    GRAPHIC DESIGN PROGRAM
                  </p>
                  <p className="font-alfabet font-normal text-black text-xs md:text-sm mb-4">(2011–2014)</p>

                  <ul className="space-y-2 font-alfabet font-light text-black text-sm leading-relaxed">
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>
                        Learn core design principles, typography, color theory, and layout for print and digital media.
                      </span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>
                        Gain hands-on experience with industry tools like Adobe Creative Cloud (Photoshop, Illustrator,
                        InDesign, After Effects).
                      </span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>
                        Build a professional portfolio through real-world projects, critiques, and studio-based
                        learning.
                      </span>
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-1">
                    BRAINSTATION
                  </h4>
                  <p className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-1">
                    FRONT-END WEB DEV COURSE
                  </p>
                  <p className="font-alfabet font-normal text-black text-xs md:text-sm mb-4">(2018)</p>

                  <ul className="space-y-2 font-alfabet font-light text-black text-sm leading-relaxed">
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Covered the fundamentals of HTML and CSS for building structured, styled web pages.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Learned responsive design using Bootstrap frameworks.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>
                        Built small front-end projects to practice layout, accessibility, and clean code structure.
                      </span>
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-alfabet font-normal text-black text-xs md:text-sm uppercase mb-4">TOOLS</h4>

                  <ul className="space-y-1 font-alfabet font-light text-black text-sm leading-relaxed">
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Figma</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Photoshop</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Illustrator,</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>InDesign</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>After Effects</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Jitter</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>HTML/CSS/JS</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Experience Column */}
            <div>
              <h3 className="font-ivyjournal italic font-normal text-black text-3xl md:text-4xl mb-12">Experience</h3>

              <div className="space-y-10">
                {/* Immunefi */}
                <div className="mb-8">
                  <h4 className="font-alfabet font-normal text-black text-sm md:text-base tracking-wide">IMMUNEFI</h4>
                  <p className="font-alfabet font-normal text-black text-xs md:text-sm mb-4">OCT 2025–PRESENT</p>

                  <ul className="space-y-2 font-alfabet font-light text-black text-sm leading-relaxed">
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Developing brand identity for a leading web3 security company.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Designing landing pages and marketing materials.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Creating social media content and campaign assets.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Producing AI-assisted illustrations for various digital platforms.</span>
                    </li>
                  </ul>
                </div>

                {/* PXL Labs */}
                <div className="mb-8">
                  <h4 className="font-alfabet font-normal text-black text-sm md:text-base tracking-wide">PXL LABS</h4>
                  <p className="font-alfabet font-normal text-black text-xs md:text-sm mb-4">NOV 2024–PRESENT</p>

                  <ul className="space-y-2 font-alfabet font-light text-black text-sm leading-relaxed">
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Led brand identity design for web3 and fintech startups.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Delivered motion graphics using After Effects for product launches.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Contributed to responsive web design.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Clients include Infrared Finance, Polygon, Blueberry, and Dinero.</span>
                    </li>
                  </ul>
                </div>

                {/* Superpower Health */}
                <div className="mb-8">
                  <h4 className="font-alfabet font-normal text-black text-sm md:text-base tracking-wide">
                    SUPERPOWER HEALTH
                  </h4>
                  <p className="font-alfabet font-normal text-black text-xs md:text-sm mb-4">
                    (FREELANCE, 1-MONTH CONTRACT) – DEC 2024
                  </p>

                  <ul className="space-y-2 font-alfabet font-light text-black text-sm leading-relaxed">
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Designed marketing materials and landing pages for a health tech startup.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Created social media assets and email designs aligned with brand tone.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Delivered fast-turnaround creative under tight timelines.</span>
                    </li>
                  </ul>
                </div>

                {/* Absurdity Studio */}
                <div className="mb-8">
                  <h4 className="font-alfabet font-normal text-black text-sm md:text-base tracking-wide">
                    ABSURDITY STUDIO
                  </h4>
                  <p className="font-alfabet font-normal text-black text-xs md:text-sm mb-4">SEPT 2024–OCT 2025</p>

                  <ul className="space-y-2 font-alfabet font-light text-black text-sm leading-relaxed">
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Design lead for a cybersecurity-focused agency.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Art directed internal designers and oversaw all phases of creative execution.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Managed timelines and collaborated directly with strategy and dev.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>
                        Focused on marketing, websites and select identity work for clients like Straiker AI, Endor
                        Labs, and Darknet Diaries.
                      </span>
                    </li>
                  </ul>
                </div>

                {/* Choko */}
                <div className="mb-8">
                  <h4 className="font-alfabet font-normal text-black text-sm md:text-base tracking-wide">CHOKO</h4>
                  <p className="font-alfabet font-normal text-black text-xs md:text-sm mb-4">JUL 2018–SEPT 2024</p>

                  <ul className="space-y-2 font-alfabet font-light text-black text-sm leading-relaxed">
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Designed apparel, packaging, and print collateral for major automotive clients.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Worked across licensing and marketing teams to deliver seasonal collections.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Supported clients like GMC, Chevrolet, Snap-on Tools, Jeep, and NASCAR.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 w-1 h-1 bg-black rounded-full flex-shrink-0" />
                      <span>Developed large-scale merch programs from concept through production.</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* THANK YOU SECTION */}
      <section className="bg-[#f8f8f8] pt-24 md:pt-32 pb-0 min-h-screen">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col items-center justify-center min-h-[80vh]">
            {/* Top plus and line */}
            <div className="text-black text-base font-light mb-3">+</div>
            <div className="w-px h-48 bg-black/30 mb-8" />

            {/* Center content */}
            <div className="flex items-center gap-12 md:gap-20">
              <h2 className="font-ivyjournal font-thin text-black text-3xl md:text-4xl lg:text-5xl">Thank You</h2>
            </div>

            {/* Bottom line - extends beyond viewport */}
            <div className="w-px h-24 bg-black/30 mt-8" />

            <div className="mt-12">
              <button
                onClick={handleContact}
                className="font-alfabet font-light text-black text-[10px] md:text-xs border border-black px-5 py-1.5 hover:bg-[#FF003C] hover:border-[#FF003C] hover:text-white transition-colors"
                style={{ borderRadius: "4px" }}
              >
                {copied ? "COPIED!" : "CONTACT"}
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
